﻿// See https://aka.ms/new-console-template for more information

using DAB_Assignment2;

App app = new App();
return app.Run();
















